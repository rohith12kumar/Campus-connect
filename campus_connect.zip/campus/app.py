import io
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, session,send_file,make_response
from pymongo import MongoClient
from werkzeug.security import check_password_hash, generate_password_hash
import os
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
import time
import gridfs
import base64
from bson.objectid import ObjectId
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key'


client = MongoClient('mongodb://localhost:27017/')
db = client['campus']
fs = gridfs.GridFS(db)

app.config['UPLOAD_FOLDER'] = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'static/uploads/')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  
app.secret_key = 'your_secret_key'  


os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

app.json_encoder = CustomJSONEncoder

@app.route('/')
def index():
    return render_template('landing.html')

@app.route('/login_render')
def login_render():
    return render_template('login.html')

@app.route('/signup_render')
def signup_render():
    return render_template('signup.html')

@app.route('/userpage')
def user_page():
    if 'email' not in session:
            return jsonify({"error": "User not logged in"}), 401
    email=session.get('email')
    username=session.get('user')
    profile_image_data = db.users.find_one({'email':email})
    profile_image = profile_image_data['profile_image'].strip()
    print(email,username,profile_image)
    return render_template('user_dashboard.html',email=email,username=username,profile_image=profile_image)

def get_registered_persons_count():
    try:
        events = list(db.events.find())
        registered_persons = set()

        for event in events:
            if 'registered_persons' in event and isinstance(event['registered_persons'], list):
                for person in event['registered_persons']:
                    if 'email' in person:
                        registered_persons.add(person['email'])

        count = len(registered_persons)

        return count

    except Exception as e:
        return str(e)

@app.route('/adminpage')
def admin_page():
    if 'email' not in session:
            return jsonify({"error": "User not logged in"}), 401
    rp_count=get_registered_persons_count()
    running_count = db.events.count_documents({"status": "upcoming"})
    completed_count = db.events.count_documents({"status": "completed"})
    return render_template('admin_dashboard.html',email='admin@gmail.com',username='Admin',rp_count=rp_count,running_count=running_count,completed_count=completed_count)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        mobile = request.form['mobile']
        password = request.form['password']
        confirm_password = request.form['confirm-password']
        
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('signup'))
        
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        
        user = {
            'name': name,
            'email': email,
            'mobile': mobile,
            'profile_image':'',
            'password': hashed_password
        }
        result = db.users.insert_one(user)
        
        if result.inserted_id:
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login_render'))
        else:
            flash('Failed to register user', 'danger')
            return redirect(url_for('signup_render'))
    
    return render_template('signup.html')

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = db.users.find_one({'email': email})
        
        if email == 'admin@gmail.com' and password == 'admin':
            session['email'] = email
            return jsonify({'success':'admin'})
        if user and check_password_hash(user['password'], password):
            session['user'] = user['name']
            session['email']= user['email']
            flash('Login successful!', 'success')
            return jsonify({'success':'user'})
        else:
            flash('Invalid email or password', 'danger')
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/upload_profile_image', methods=['POST'])
def upload_profile_image():
    if 'profile_image' not in request.files:
        return redirect(request.url)

    file = request.files['profile_image']
    email = request.form['profile_email']

    if file.filename == '':
        return redirect(request.url)

    if file:
        filename = secure_filename(file.filename)
        unique_filename = f"{int(time.time())}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        try:
            file.save(file_path)  
            print(f"File saved successfully: {file_path}")

        
            db.users.update_one(
                {'username': 'your_username'},  
                {'$set': {'profile_image': f'static/uploads/{unique_filename}'}}
            )
        except Exception as e:
            print(f"Error saving file: {e}")  


        db.users.update_one(
            {'email': email},
            {'$set': {'profile_image': f'/static/uploads/{unique_filename}'}}
        )

    return redirect(url_for('user_page'))

@app.route('/api/get_events', methods=['GET'])
def get_events():
    try:
        if 'email' not in session:
            return jsonify({"error": "User not logged in"}), 401
        user_email = session['email']
        events = list(db.events.find({
            "registered_persons.email": {"$ne": user_email}
        }))
        currenttime=datetime.now()
        for event in events: 
            event['start'] = event['start'].isoformat()  
            event['end'] = event['end'].isoformat()
            event_end = datetime.fromisoformat(event['end'])
            if event_end < currenttime:
                    db.events.update_one({"_id": event['_id']},{"$set": {"status": "completed"}})
            print(event['end'])  
            event['_id'] = str(event['_id'])  
        return jsonify(events)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route('/api/get_event_details/<event_id>', methods=['GET'])
def get_event_details(event_id):
    try:
        events = list(db.events.find({'_id': ObjectId(event_id)}))
        for event in events:
            event['_id'] = str(event['_id']) 
            event['start'] = event['start'].isoformat()
            event['end'] = event['end'].isoformat()      
        return jsonify({"events":events[0]}),200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    


@app.route('/api/events', methods=['GET', 'POST'])
def events():
    if request.method == 'GET':
        try:
            start_str = request.args.get('start')
            end_str = request.args.get('end')
            

            start = datetime.fromisoformat(start_str)
            end = datetime.fromisoformat(end_str)

            events = list(db.events.find({
                'start': {'$gte': start},
                'end': {'$lte': end}
            }))
            
            for event in events:
                event['start'] = event['start'].isoformat()
                event['_id'] = str(event['_id'])
                event['end'] = event['end'].isoformat()
            return jsonify(events)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
        
    elif request.method == 'POST':
        try:
            data = request.json
            start = datetime.fromisoformat(data['start'])
            end = datetime.fromisoformat(data['end'])
            event = {
                'title': data['title'],
                'description': data['description'],
                'registered_persons':[],
                'status':'upcoming',
                'start': start,
                'end': end
            }
            result = db.events.insert_one(event)
            return jsonify({"_id": str(result.inserted_id)})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

@app.route('/api/events/<event_id>', methods=['PUT'])
def update_event(event_id):
    try:
        data = request.json
        start = datetime.fromisoformat(data['start'])
        end = datetime.fromisoformat(data['end'])
        current_time=datetime.now()
        if end < current_time:
            update_fields = {
                'title': data['title'],
                'description': data['description'],
                'start': start,
                'status':'completed',
                'end': end
            }
        else:
            update_fields = {
                'title': data['title'],
                'description': data['description'],
                'status':'upcoming',
                'start': start,
                'end': end
            }
        db.events.update_one({'_id': ObjectId(event_id)}, {'$set': update_fields})
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
    
@app.route('/api/resources/library', methods=['POST'])
def upload_library():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    try:
        file_id = fs.put(file, filename=file.filename)
        db.resources.insert_one({
            'title': file.filename,
            'semester': request.form.get('semester'),
            'branch': request.form.get('branch'),
            'file_id': str(file_id)
        })
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/resources/tutorials', methods=['POST'])
def upload_tutorials():
    try:
        data = request.json
        title=data.get('title')
        link = data.get('link')
        sem =data.get('sem')
        branch=data.get('branch')
        db.tutorials.insert_one({'title':title,'link': link,'semester':sem,'branch':branch})
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/announcements', methods=['POST'])
def add_announcement():
    try:
        data = request.json
        db.announcements.insert_one({
            'title': data['title'],
            'description': data['body'],
            'date': datetime.now()
        })
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/resources', methods=['GET'])
def get_resources():
    try:
        resources = list(db.resources.find())
        for resource in resources:
            resource['_id'] = str(resource['_id'])  
        return jsonify(resources)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tutorials', methods=['GET'])
def get_tutorials():
    try:
        tutorials = list(db.tutorials.find())
        for tutorial in tutorials:
            tutorial['_id'] = str(tutorial['_id'])
        return jsonify(tutorials)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/announcements', methods=['GET'])
def get_announcements():
    try:
        announcements = list(db.announcements.find())
        for announcement in announcements:
            announcement['_id'] = str(announcement['_id']) 
        return jsonify(announcements)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/booked_events', methods=['GET'])
def get_booked_events():
    try:
        if 'email' not in session:
            return jsonify({"error": "User not logged in"}), 401

        user_email = session['email']

        bookedevents = list(db.events.find({
            "registered_persons.email": user_email 
        }))
        for event in bookedevents:
            event['start'] = event['start'].isoformat()
            event['end'] = event['end'].isoformat()
            event['_id'] = str(event['_id'])
        return jsonify(bookedevents)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route('/api/download_resource/<file_id>', methods=['GET'])
def download_resource(file_id):
    try:
        file = fs.get(ObjectId(file_id))
        file_stream = io.BytesIO(file.read())
        
        
        return send_file(
            file_stream,
            as_attachment=True,
            download_name=file.filename,
            mimetype='application/octet-stream'
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/api/register_event', methods=['POST'])
def register_event():
   try:
        
        data = request.get_json()
        user_name = data.get('username')
        user_email = data.get('email')
        phone = data.get('phone')
        event_id = data.get('eventId')  

        
        
        event = db.events.find_one({"_id": ObjectId(event_id)})
        if not event:
            return jsonify({"success": False, "message": "Event not found"}), 404

        
        current_time = datetime.now()
        print(current_time)
        if event['end'] < current_time:
            db.events.update_one(
                {"_id": ObjectId(event_id)},
                {"$set": {"status": "completed"}}
            )
        

       
        db.events.update_one(
            {"_id": ObjectId(event_id)},
            {"$push": {"registered_persons": {"email": user_email}}}
        )

        return jsonify({"success": True, "message": "Registered successfully!"})

   except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500
   
@app.route('/admin_events_table', methods=['GET'])
def admin_events_table():
    events=list(db.events.find())
    for event in events:
        event['_id']=str(event['_id'])
        event['status']=event['status'].title()
        event['title']=event['title'].title()
        event['description']=event['description'].title()
    return jsonify(events)

@app.route('/logout')
def logout():
    session.clear() 
    return redirect(url_for('index')) 




if __name__ == '__main__':
    app.run(debug=True)
