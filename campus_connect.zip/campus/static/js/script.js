// Open event modal
function openEventModal() {
    document.getElementById('eventModal').style.display = 'block';
}

// Close event modal
function closeEventModal() {
    document.getElementById('eventModal').style.display = 'none';
}

// Open resource modal
function openResourceModal() {
    document.getElementById('resourceModal').style.display = 'block';
}

// Close resource modal
function closeResourceModal() {
    document.getElementById('resourceModal').style.display = 'none';
}

// Open chat modal
function openChat() {
    document.getElementById('chatModal').style.display = 'block';
}

// Close chat modal
function closeChat() {
    document.getElementById('chatModal').style.display = 'none';
}
